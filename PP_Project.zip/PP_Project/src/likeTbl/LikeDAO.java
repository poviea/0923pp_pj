package likeTbl;

public class LikeDAO {

}
