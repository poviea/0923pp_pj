package comment;

public class CommentDAO {

}
