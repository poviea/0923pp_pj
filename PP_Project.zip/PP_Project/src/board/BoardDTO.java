package board;

public class BoardDTO {

}
