package board;

public class BoardDAO {

}
