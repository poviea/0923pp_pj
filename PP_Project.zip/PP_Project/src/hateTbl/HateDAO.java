package hateTbl;

public class HateDAO {

}
