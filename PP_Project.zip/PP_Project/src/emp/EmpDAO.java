package emp;

public class EmpDAO {

}
