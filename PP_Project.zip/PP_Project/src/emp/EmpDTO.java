package emp;

public class EmpDTO {

}
